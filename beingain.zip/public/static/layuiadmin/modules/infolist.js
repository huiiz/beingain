/**

 @Name：layuiAdmin 内容系统
 @Author：star1029
 @Site：http://www.layui.com/admin/
 @License：LPPL
    
 */


layui.define(['table', 'form'], function(exports){
  var $ = layui.$
  ,table = layui.table
  ,setter = layui.setter
  ,form = layui.form;

  //通知管理
  table.render({
    elem: '#LAY-app-content-list'
    ,url: '/info/manage/getinfolist' //模拟接口
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 60, title: 'ID', sort: true}
      ,{field: 'title', width: 120, title: '公告标题'}
      ,{field: 'author', title: '作者'}
      ,{field: 'create_time', width: 170, title: '创建时间', sort: true}
      ,{field: 'last_time', width: 170, title: '过期时间', sort: true}
      ,{field: 'visit', width: 90, title: '阅读数'}
      ,{field: 'status', title: '发布状态', templet: '#buttonTpl', minWidth: 80, align: 'center'}
      ,{title: '操作', minWidth: 150, align: 'center', fixed: 'right', toolbar: '#table-content-list'}
    ]]
    ,page: true
    ,limit: 10
    ,limits: [10, 15, 20, 25, 30]
    ,text: '对不起，加载出现异常！'
  });
  
  //监听工具条
  table.on('tool(LAY-app-content-list)', function(obj){
    var data = obj.data;
    var id = data.id;
    if(obj.event === 'del'){
      layer.confirm('确定删除此条公告?', function(index){
        $.ajax({
          url:'delinfo/id/'+id,
          method:"GET",
          success:function (res) {
            layer.msg(res.msg);
            layer.close(index);
            table.reload('LAY-app-content-list');
          }
        });

      });
    } else if(obj.event === 'edit'){
      layer.open({
        type: 2
        ,title: '编辑公告'
        ,content: '/info/manage/editinfoform/?id='+ data.id
        ,maxmin: true
        ,area: ['650px', '450px']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submit = layero.find('iframe').contents().find("#layuiadmin-app-form-edit");
          debugger;
          //监听提交
          iframeWindow.layui.form.on('submit(layuiadmin-app-form-edit)', function(data){
            var field = data.field; //获取提交的字段
          var response = setter.response;
            //提交 Ajax 成功后，静态更新表格中的数据
            $.ajax({
              url:'editinfo/id/'+id,
              method:"POST",
              data: field,
              success:function (res) {
                var statusCode = response.statusCode;
                if(res[response.statusName] == statusCode.ok) {
                  layer.msg(res.msg);
                  table.reload('LAY-app-content-tags');
                  // layer.close(index);
                }
                // 提示错误（要求返回码为-1）
                else if(res[response.statusName] == statusCode.error) {
                  layer.msg(res.msg);
                }
              }
            });
            obj.update({
              label: field.label
              ,title: field.title
              ,author: field.author
              ,status: field.status
              ,content: field.content
            }); //数据更新
            
            form.render();
            // layer.close(index); //关闭弹层
          });  
          
          submit.trigger('click');
        }
      });
    }
  });

  //分类管理
  table.render({
    elem: '#LAY-app-content-tags'
    ,url: '/news/manage/gettags' //接口
    ,cols: [[
      {type: 'numbers', fixed: 'left'}
      ,{field: 'id', width: 100, title: 'ID', sort: true}
      ,{field: 'parent', width: 200, title: '父级分类'}
      ,{field: 'name', title: '分类名', minWidth: 200}
      ,{title: '操作', width: 150, align: 'center', fixed: 'right', toolbar: '#layuiadmin-app-cont-tagsbar'}
    ]]
    ,text: '对不起，加载出现异常！'
  });
  
  //监听工具条
  table.on('tool(LAY-app-content-tags)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
      layer.confirm('确定删除分类？', function(index){
        $.ajax({
          url:'/news/manage/delcategory/id/' + data.id,
          method:"GET",
          success:function (res) {
            layer.msg(res.msg);
            table.reload('LAY-app-content-tags'); //数据刷新
            layer.close(index); //关闭弹层
          }
        });
      });
    } else if(obj.event === 'edit'){
      var tr = $(obj.tr);
      layer.open({
        type: 2
        ,title: '编辑分类'
        ,content: '/news/manage/tagsform?type=edit&id='+ data.id
        ,area: ['450px', '400px']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          //获取iframe元素的值
          console.log("123");
          var othis = layero.find('iframe').contents().find("#layuiadmin-app-form-tags")
          ,tags = othis.find('input[name="tags"]').val();

          console.log(othis);
          console.log(tags);


          obj.update({
            tags: tags
          });
          layer.close(index);
        }
        ,success: function(layero, index){
          //给iframe元素赋值
          var othis = layero.find('iframe').contents().find("#layuiadmin-app-form-tags").click();
          othis.find('input[name="tags"]').val(data.tags);
        }
      });
    }
  });

  //评论管理
  table.render({
    elem: '#LAY-app-content-comm'
    ,url: layui.setter.base + 'json/content/comment.js' //模拟接口
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 100, title: 'ID', sort: true}
      ,{field: 'reviewers', title: '评论者', minWidth: 100}
      ,{field: 'content', title: '评论内容', minWidth: 100}
      ,{field: 'commtime', title: '评论时间', minWidth: 100, sort: true}
      ,{title: '操作', width: 150, align: 'center', fixed: 'right', toolbar: '#table-content-com'}
    ]]
    ,page: true
    ,limit: 10
    ,limits: [10, 15, 20, 25, 30]
    ,text: '对不起，加载出现异常！'
  });
  
  //监听工具条
  table.on('tool(LAY-app-content-comm)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
      layer.confirm('确定删除此条评论？', function(index){
        obj.del();
        layer.close(index);
      });
    } else if(obj.event === 'edit') {
      layer.open({
        type: 2
        ,title: '编辑评论'
        ,content: '../../../views/app/content/contform.html'
        ,area: ['450px', '300px']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'layuiadmin-app-comm-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段
            
            //提交 Ajax 成功后，静态更新表格中的数据
            //$.ajax({});
            table.reload('LAY-app-content-comm'); //数据刷新
            layer.close(index); //关闭弹层
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    }
  });

  exports('contlist', {})
});