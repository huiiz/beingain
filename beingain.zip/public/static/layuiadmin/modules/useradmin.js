/**

 @Name：layuiAdmin 用户管理 管理员管理 角色管理
 @Author：star1029
 @Site：http://www.layui.com/admin/
 @License：LPPL
    
 */


layui.define(['table', 'form'], function(exports){
  var $ = layui.$
  ,table = layui.table
  ,setter = layui.setter
  ,form = layui.form;

  //用户管理
  table.render({
    elem: '#LAY-user-manage'
    ,url: '/user/manage/getuserlist' //模拟接口
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 60, title: 'ID', sort: true}
      ,{field: 'username', title: '用户名', minWidth: 100}
      ,{field: 'headimg', title: '头像', width: 100, templet: '#imgtmp'}
      ,{field: 'email', title: '邮箱'}
      ,{field: 'gender', width: 60, title: '性别'}
      ,{field: 'create_time', width: 160, title: '加入时间', sort: true}
      ,{field: 'status', title: '状态'}
      ,{title: '操作', width: 150, align:'center', fixed: 'right', toolbar: '#table-useradmin-webuser'}
    ]]
    ,page: true
    ,limit: 30
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  
  //监听工具条
  table.on('tool(LAY-user-manage)', function(obj){
    var data = obj.data;
    var id = data.id;
    if(obj.event === 'del'){
      layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
        
        layer.confirm('真的删除行么', function(index){
          obj.del();
          layer.close(index);
        });
      });
    } else if(obj.event === 'edit'){
      var tr = $(obj.tr);

      layer.open({
        type: 2
        ,title: '编辑用户'
        ,content: '/user/manage/userform?type=edit&id='+id
        ,maxmin: true
        ,area: ['500px', '450px']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-user-front-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID)
          ,response = setter.response;;

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段
            
            //提交 Ajax 成功后，静态更新表格中的数据
            $.ajax({
              url:'/user/manage/edituser/id/'+id,
              method:"POST",
              data: field,
              success:function (res) {
                var statusCode = response.statusCode;
                if(res[response.statusName] == statusCode.ok) {
                  layer.msg(res.msg);
                  table.reload('LAY-user-front-submit'); //数据刷新
                  layer.close(index); //关闭弹层
                }
                // 提示错误（要求返回码为-1）
                else if(res[response.statusName] == statusCode.error) {
                  layer.msg(res.msg);
                }

              },
              error:function (res) {
                layer.msg("发生错误！请联系管理员");
                console.log("失败");
              }
            });
          });


          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    }
  });

  //管理员管理
  table.render({
    elem: '#LAY-user-back-manage'
    ,url: '/admin/admin/getlist' //接口
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 50, title: 'ID'}
      ,{field: 'username', width: 120, title: '登录名'}
      ,{field: 'email', width: 170, title: '邮箱'}
      ,{field: 'phone', width: 120, title: '手机号'}
      ,{field: 'nickname', width: 70, title: '昵称'}
      ,{field: 'groups', width: 100, title: '权限'}
      ,{field: 'create_time', title: '加入时间'}
      ,{title: '操作', width: 150, align: 'center', fixed: 'right', toolbar: '#table-useradmin-admin'}
    ]]
    ,text: '对不起，加载出现异常！'
  });
  
  //监听工具条
  table.on('tool(LAY-user-back-manage)', function(obj){
    var data = obj.data;
    var id = data.id;
    if(obj.event === 'del'){
      layer.confirm('确定删除此管理员？', function(index){
        $.ajax({
          url:'/admin/admin/del/id/' + data.id,
          method:"GET",
          success:function (res) {
            console.log(res);
            table.reload('LAY-user-back-manage'); //数据刷新
            layer.close(index); //关闭弹层
          }
        });
      });
    }else if(obj.event === 'edit'){
      var tr = $(obj.tr);

      layer.open({
        type: 2
        ,title: '编辑管理员'
        ,content: '/admin/admin/adminform?type=edit&id='+id
        ,area: ['420px', '380px']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          console.log("编辑开始");
          // debugger;
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-user-back-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID)
          ,response = setter.response;
          console.log(submit);
          // debugger;
          //监听提交
          iframeWindow.layui.form.on('submit('+submitID+')', function(data){
            var field = data.field; //获取提交的字段
            //提交 Ajax 成功后，静态更新表格中的数据
            $.ajax({
              url:'/admin/admin/editadmin/id/'+id,
              method:"POST",
              data: field,
              success:function (res) {
                var statusCode = response.statusCode;
                if(res[response.statusName] == statusCode.ok) {
                  layer.msg(res.msg);
                  table.reload('LAY-user-back-manage'); //数据刷新
                  layer.close(index); //关闭弹层
                }
                // 提示错误（要求返回码为-1）
                else if(res[response.statusName] == statusCode.error) {
                  layer.msg(res.msg);
                }

              },
              error:function (res) {
                layer.msg("发生错误！请联系管理员");
                console.log("失败");
              }
            });
          });

          submit.trigger('click');
        }
        ,success: function(layero, index){
          console.log("打开成功");
        }
      })
    }
  });

  //角色管理
  table.render({
    elem: '#LAY-user-back-role'
    ,url: layui.setter.base + 'json/useradmin/role.js' //模拟接口
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 80, title: 'ID', sort: true}
      ,{field: 'rolename', title: '角色名'}
      ,{field: 'limits', title: '拥有权限'}
      ,{field: 'descr', title: '具体描述'}
      ,{title: '操作', width: 150, align: 'center', fixed: 'right', toolbar: '#table-useradmin-admin'}
    ]]
    ,text: '对不起，加载出现异常！'
  });
  
  //监听工具条
  table.on('tool(LAY-user-back-role)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
      layer.confirm('确定删除此角色？', function(index){
        obj.del();
        layer.close(index);
      });
    }else if(obj.event === 'edit'){
      var tr = $(obj.tr);

      layer.open({
        type: 2
        ,title: '编辑角色'
        ,content: '../../../views/user/administrators/roleform.html'
        ,area: ['500px', '480px']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submit = layero.find('iframe').contents().find("#LAY-user-role-submit");

          //监听提交
          iframeWindow.layui.form.on('submit(LAY-user-role-submit)', function(data){
            var field = data.field; //获取提交的字段
            
            //提交 Ajax 成功后，静态更新表格中的数据
            //$.ajax({});
            table.reload('LAY-user-back-role'); //数据刷新
            layer.close(index); //关闭弹层
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
        
        }
      })
    }
  });

  exports('useradmin', {})
});