/**

 @Name：layuiAdmin 内容系统
 @Author：star1029
 @Site：http://www.layui.com/admin/
 @License：LPPL

 */


layui.define(['table', 'form'], function(exports){
    var $ = layui.$
        ,table = layui.table
        ,setter = layui.setter
        ,form = layui.form;

    //笔记管理
    table.render({
        elem: '#LAY-app-note-list'
        ,url: '/home/manage/notelist' //模拟接口
        ,cols: [[
            {type: 'checkbox', fixed: 'left'}
            ,{field: 'id', width: 60, title: 'ID', sort: true}
            ,{field: 'username',title: '记录人', sort: true}
            ,{field: 'title',title: '标题'}
            ,{field: 'create_time', title: '创建时间', sort: true}
            ,{field: 'update_time', title: '更新时间',}
            ,{title: '操作', minWidth: 150, align: 'center', fixed: 'right', toolbar: '#table-content-list'}
        ]]
        ,page: true
        ,limit: 10
        ,limits: [10, 15, 20, 25, 30]
        ,text: '对不起，加载出现异常！'
    });

    table.on('tool(LAY-app-note-list)', function(obj) {
        var data = obj.data;
        var id = data.id;
        if (obj.event === 'read') {
            layer.open({
                type: 2
                ,title: '查看'
                ,content: '/home/manage/noteform?id='+id
                ,area: ['450px', '470px']

            })
        }
    });




    //打卡管理
    table.render({
        elem: '#LAY-app-checkin-list'
        ,url: '/home/manage/checkinlist' //模拟接口
        ,cols: [[
            {type: 'checkbox', fixed: 'left'}
            ,{field: 'id', width: 60, title: 'ID', sort: true}
            ,{field: 'day',  title: '打卡日期', sort: true}
            ,{field: 'username', title: '打卡人', sort: true}
            ,{field: 'create_time', title: '打卡时间', sort: true}
            ,{field: 'content', title: '打卡内容', sort: true}
            ,{title: '操作', minWidth: 150, align: 'center', fixed: 'right', toolbar: '#table-content-list'}
        ]]
        ,page: true
        ,limit: 10
        ,limits: [10, 15, 20, 25, 30]
        ,text: '对不起，加载出现异常！'
    });

    table.on('tool(LAY-app-checkin-list)', function(obj) {
        var data = obj.data;
        var id = data.id;
        if (obj.event === 'read') {
            layer.open({
                type: 2
                ,title: '查看'
                ,content: '/home/manage/checkinform?id='+id
                ,area: ['600px', '470px']

            })
        }
    });




    //收藏管理
    table.render({
        elem: '#LAY-app-collection-list'
        ,url: '/home/manage/collectionlist' //模拟接口
        ,cols: [[
            {type: 'checkbox', fixed: 'left'}
            ,{field: 'id', width: 60, title: 'ID', sort: true}
            ,{field: 'username', title: '收藏人', sort: true}
            ,{field: 'subject', title: '帖子主题', sort: true}
            ,{field: 'sid',title: '帖子id', sort: true}
            ,{field: 'create_time', title: '收藏时间', sort: true}
            ,{title: '操作', minWidth: 150, align: 'center', fixed: 'right', toolbar: '#table-content-list'}
        ]]
        ,page: true
        ,limit: 10
        ,limits: [10, 15, 20, 25, 30]
        ,text: '对不起，加载出现异常！'
    });

    table.on('tool(LAY-app-collection-list)', function(obj) {
        var data = obj.data;
        var id = data.id;
        if (obj.event === 'read') {
            layer.open({
                type: 2
                ,title: '查看'
                ,content: '/home/manage/collectionform?id='+id
                ,area: ['450px', '470px']

            })
        }
    });



    //待办管理
    table.render({
        elem: '#LAY-app-backlog-list'
        ,url: '/home/manage/backloglist' //模拟接口
        ,cols: [[
            {type: 'checkbox', fixed: 'left'}
            ,{field: 'id', width: 60, title: 'ID', sort: true}
            ,{field: 'username', title: '发起人'}
            ,{field: 'content', title: '事项 '}
            ,{field: 'create_time',title: '创建时间', sort: true}
            ,{field: 'deadline',title: '截至时间'}
            ,{field: 'status', title: '完成状态', templet: '#buttonTpl', minWidth: 80, align: 'center', sort: true}
            ,{title: '操作', minWidth: 150, align: 'center', fixed: 'right', toolbar: '#table-content-list'}
        ]]
        ,page: true
        ,limit: 10
        ,limits: [10, 15, 20, 25, 30]
        ,text: '对不起，加载出现异常！'
    });

    table.on('tool(LAY-app-backlog-list)', function(obj) {
        var data = obj.data;
        var id = data.id;
        if (obj.event === 'read') {
            layer.open({
                type: 2
                ,title: '查看'
                ,content: '/home/manage/backlogform?id='+id
                ,area: ['600px', '470px']

            })
        }
    });

    exports('homels', {})
});