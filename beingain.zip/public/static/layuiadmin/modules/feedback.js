/**

 @Name：layuiAdmin 社区系统
 @Author：star1029
 @Site：http://www.layui.com/admin/
 @License：LPPL

 */


layui.define(['table', 'form'], function(exports){
    var $ = layui.$
        ,table = layui.table
        ,setter = layui.setter
        ,form = layui.form;

    //帖子管理
    table.render({
        elem: '#LAY-app-feedback-list'
        ,url: '/feedback/manage/getlist' //模拟接口
        ,cols: [[
            {type: 'checkbox', fixed: 'left'}
            ,{field: 'id', width: 60, title: 'ID', sort: true}
            ,{field: 'username', title: '用户'}
            // ,{field: 'email', title: '电子邮箱'}
            ,{field: 'subject', title: '主题'}
            // ,{field: 'content', title: '内容'}
            ,{field: 'create_time', title: '反馈时间', width: 180}
            ,{field: 'update_time', title: '更新时间', width: 180}
            ,{field: 'status', title: '状态', templet: '#buttonTpl', align: 'center', sort: true}
            ,{title: '操作', width: 150, align: 'center', fixed: 'right', toolbar: '#table-forum-list'}
        ]]
        ,page: true
        ,limit: 10
        ,limits: [10, 15, 20, 25, 30]
        ,text: '对不起，加载出现异常！'
    });

    //监听工具条
    table.on('tool(LAY-app-feedback-list)', function(obj){
        var data = obj.data
            ,response = setter.response;
        var id = data.id;
        if(obj.event === 'edit'){
            var tr = $(obj.tr);
            layer.open({
                type: 2
                ,title: '反馈详情'
                ,content: '/feedback/manage/feedform/id/'+id
                ,area: ['550px', '500px']
                ,btn: ['确定', '取消']
                ,resize: false
                ,yes: function(index, layero){
                    var iframeWindow = window['layui-layer-iframe'+ index]
                        ,submitID = 'LAY-app-forum-submit'
                        ,submit = layero.find('iframe').contents().find('#'+ submitID);

                    //监听提交
                    iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
                        var field = data.field
                            ,response = setter.response; //获取提交的字段

                        //提交 Ajax 成功后，静态更新表格中的数据
                        $.ajax({
                            url:'/feedback/manage/reply/id/'+id,
                            method:"POST",
                            data: field,
                            success:function (res) {
                                var statusCode = response.statusCode;
                                if(res[response.statusName] == statusCode.ok) {
                                    layer.msg(res.msg);
                                    table.reload('LAY-app-feedback-list'); //数据刷新
                                    layer.close(index); //关闭弹层
                                }
                                // 提示错误（要求返回码为-1）
                                else if(res[response.statusName] == statusCode.error) {
                                    layer.msg(res.msg);
                                }}
                        });

                    });

                    submit.trigger('click');
                }
                ,success: function(layero, index){

                }
            });
        }
    });



    exports('feedback', {})
});