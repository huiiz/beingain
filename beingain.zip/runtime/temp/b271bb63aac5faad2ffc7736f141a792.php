<?php /*a:1:{s:71:"F:\ProgramLanguage\PHP\beingain\application\index\view\index\index.html";i:1595082951;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>首页</title>
    <style>
        button{
            /*width: 300px;*/
            height: 100px;
            font-size: 50px;
            margin: 0 auto;
            display: block;
        }
    </style>
</head>
<body>
<button type="button" onclick="admin()">转跳到后台</button><br /><br /><br />
<button type="button" onclick="book()">转跳到项目文档</button>

<script>
    function admin() {
        location.href='/admin';
    };
    function book() {
        location.href='https://www.showdoc.cc/beingain';
    }
</script>
</body>
</html>