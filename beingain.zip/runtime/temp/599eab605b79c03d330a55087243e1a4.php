<?php /*a:1:{s:78:"F:\ProgramLanguage\PHP\beingain\application\feedback\view\manage\feedform.html";i:1595133743;}*/ ?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>反馈管理 iframe 框</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" type="text/css" href="/static/layuiadmin/layui/css/layui.css" />
    <link rel="stylesheet" type="text/css" href="/static/layuiadmin/style/admin.css" />
    <style>
        textarea{
            height: 30%;
        }
    </style>
</head>
<body>

<div class="layui-form" lay-filter="layuiadmin-form-list" id="layuiadmin-form-list" style="padding: 20px 30px 0 0;">
    <div class="layui-form-item">
        <label class="layui-form-label">反馈人</label>
        <div class="layui-input-block">
            <input type="text" value="<?php echo htmlentities($feedback['username']); ?>" class="layui-input" disabled>
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">邮箱</label>
        <div class="layui-input-block">
            <input type="text" value="<?php echo htmlentities($feedback['email']); ?>" name="email" class="layui-input" disabled>
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">反馈主题</label>
        <div class="layui-input-block">
            <input type="text" value="<?php echo htmlentities($feedback['subject']); ?>" class="layui-input" disabled>
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">反馈内容</label>
        <div class="layui-input-block">
            <textarea type="text" class="layui-input" disabled class="layui-textarea"><?php echo htmlentities($feedback['content']); ?></textarea>
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">已解决?</label>
        <div class="layui-input-block">
            <input type="checkbox" lay-filter="switch" lay-verify="required"  lay-skin="switch" lay-text="是|否" <?php if($feedback['solved']==1): ?>checked<?php endif; ?> disabled>
        </div>
    </div>
    <?php if($feedback['solved']==0): ?>
    <div class="layui-form-item">
        <label class="layui-form-label">回复</label>
        <div class="layui-input-block">
            <textarea type="text"   cols="50" rows="6"  name="back" placeholder="在此输入要回复的内容，稍后系统将会将此内容发送到该用户邮箱。"><?php echo $back; ?></textarea>
        </div>
    </div>
    <div class="layui-form-item layui-hide">
        <input type="button" lay-submit lay-filter="LAY-app-forum-submit" id="LAY-app-forum-submit" value="回复">
    </div>
    <?php else: ?>

    <div class="layui-form-item">
        <label class="layui-form-label">回复内容</label>
        <div class="layui-input-block">
            <textarea type="text" disabled cols="50" rows="6" ><?php echo $feedback['back']; ?></textarea>
        </div>
    </div>

    <div class="layui-form-item layui-hide">
        <input type="button" lay-filter="LAY-app-forum-submit" value="确认">
    </div>

    <?php endif; ?>
</div>

<script type="text/javascript" src="/static/layuiadmin/layui/layui.js"></script>
<script>
    layui.config({
        base: '/static/layuiadmin/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'form', 'upload'], function(){
        var $ = layui.$
            ,form = layui.form
            ,upload = layui.upload;

        upload.render({
            elem: '#layuiadmin-upload-list'
            ,url: layui.setter.base + 'json/upload/demo.js'
            ,accept: 'images'
            ,method: 'get'
            ,acceptMime: 'image/*'
            ,done: function(res){
                $(this.item).prev("div").children("input").val(res.data.src)
            }
        });
    })
</script>
</body>
</html>