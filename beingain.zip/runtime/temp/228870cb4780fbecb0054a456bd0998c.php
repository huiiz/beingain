<?php /*a:1:{s:78:"F:\ProgramLanguage\PHP\beingain\application\feedback\view\manage\feedlist.html";i:1595133687;}*/ ?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>用户反馈</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" type="text/css" href="/static/layuiadmin/layui/css/layui.css" />
    <link rel="stylesheet" type="text/css" href="/static/layuiadmin/style/admin.css" />
</head>
<body>

<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-card-body">
            <table id="LAY-app-feedback-list" lay-filter="LAY-app-feedback-list"></table>
            <script type="text/html" id="buttonTpl">
                {{#  if(d.solved==1){ }}
                <button class="layui-btn layui-btn-xs">已回复</button>
                {{#  } else { }}
                <button class="layui-btn layui-btn-primary layui-btn-xs">未解决</button>
                {{#  } }}
            </script>
            <script type="text/html" id="table-forum-list">
                <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="edit"><i class="layui-icon layui-icon-edit"></i>查看</a>
            </script>
        </div>
    </div>
</div>

<script type="text/javascript" src="/static/layuiadmin/layui/layui.js"></script>
<script>
    layui.config({
        base: '/static/layuiadmin/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'feedback', 'table'], function(){
        var table = layui.table
            ,form = layui.form;


        $('.layui-btn.layuiadmin-btn-list').on('click', function(){
            var type = $(this).data('type');
            active[type] ? active[type].call(this) : '';
        });

    });
</script>
</body>
</html>
