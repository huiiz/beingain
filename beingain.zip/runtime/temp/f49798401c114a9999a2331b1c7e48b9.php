<?php /*a:1:{s:70:"F:\ProgramLanguage\PHP\beingain\application\admin\view\home\index.html";i:1593495870;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>后台-首页</title>
</head>
<body>
    <h1 style="text-align: center"><?php echo htmlentities($name); ?></h1>
    <h3 style="text-align: center">后台首页</h3>
</body>
</html>