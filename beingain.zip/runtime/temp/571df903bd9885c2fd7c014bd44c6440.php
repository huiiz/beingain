<?php /*a:1:{s:72:"F:\ProgramLanguage\PHP\beingain\application\admin\view\system\email.html";i:1594775644;}*/ ?>


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>邮件服务</title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
  <link rel="stylesheet" type="text/css" href="/static/layuiadmin/layui/css/layui.css" />
  <link rel="stylesheet" type="text/css" href="/static/layuiadmin/style/admin.css" />
</head>
<body>

<div class="layui-fluid">
  <div class="layui-row layui-col-space15">
    <div class="layui-col-md12">
      <div class="layui-card">
        <div class="layui-card-header">邮件服务</div>
        <div class="layui-card-body">

          <div class="layui-form" wid100 lay-filter="">
            <div class="layui-form-item">
              <label class="layui-form-label">SMTP服务器</label>
              <div class="layui-input-inline">
                <input type="text" name="host" value="<?php echo htmlentities($host); ?>" class="layui-input">
              </div>
              <div class="layui-form-mid layui-word-aux">如：smtp.163.com</div>
            </div>
            <div class="layui-form-item">
              <label class="layui-form-label">SMTP端口号</label>
              <div class="layui-input-inline" style="width: 80px;">
                <input type="text" name="port" lay-verify="number" value="<?php echo htmlentities($port); ?>" class="layui-input">
              </div>
              <div class="layui-form-mid layui-word-aux">一般为 25 或 465</div>
            </div>
            <div class="layui-form-item">
              <label class="layui-form-label">发送协议</label>
              <div class="layui-input-inline">
                <input type="text" name="secure" value="<?php echo htmlentities($secure); ?>" autocomplete="off" class="layui-input">
              </div>
            </div>
            <div class="layui-form-item">
              <label class="layui-form-label">发件人邮箱</label>
              <div class="layui-input-inline">
                <input type="text" name="address" value="<?php echo htmlentities($address); ?>" lay-verify="email" autocomplete="off" class="layui-input">
              </div>
            </div>
            <div class="layui-form-item">
              <label class="layui-form-label">发件人昵称</label>
              <div class="layui-input-inline">
                <input type="text" name="name" value="<?php echo htmlentities($name); ?>" autocomplete="off" class="layui-input">
              </div>
            </div>
            <div class="layui-form-item">
              <label class="layui-form-label">邮箱登入密码</label>
              <div class="layui-input-inline">
                <input type="password" name="password" value="<?php echo htmlentities($password); ?>" autocomplete="off" class="layui-input">
              </div>
            </div>
            <div class="layui-form-item">
              <div class="layui-input-block">
                <button class="layui-btn" lay-submit lay-filter="set_system_email">确认保存</button>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript" src="/static/layuiadmin/layui/layui.js"></script>
<script>
  layui.config({
    base: '/static/layuiadmin/' //静态资源所在路径
  }).extend({
    index: 'lib/index' //主入口模块
  }).use(['index', 'set']);
</script>
</body>
</html>