<?php


namespace app\user\model;


use think\Model;

class EmailCode extends Model
{

}