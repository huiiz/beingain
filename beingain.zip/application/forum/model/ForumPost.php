<?php


namespace app\forum\model;


use think\Model;

class ForumPost extends Model
{
    public function setTopAttr($value)
    {
        if ($value == "on"){
            return 1;
        } else{
            return 0;
        }
    }
}