<?php


namespace app\forum\model;


use think\Model;

class ForumCategory extends Model
{

}