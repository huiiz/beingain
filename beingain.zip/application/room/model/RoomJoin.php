<?php


namespace app\room\model;

use think\model\concern\SoftDelete;
use think\Model;

class RoomJoin extends Model
{
    use SoftDelete;
}