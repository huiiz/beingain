<?php


namespace app\room\model;

use think\model\concern\SoftDelete;
use think\Model;

class RoomStart extends Model
{
    use SoftDelete;
}