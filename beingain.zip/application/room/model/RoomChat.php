<?php
/*
 * Author :  HUII
 */

namespace app\room\model;


use think\Model;

class RoomChat extends Model
{

}