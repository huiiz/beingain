<?php


namespace app\room\controller;

use app\admin\controller\Base;

class Manage extends Base
{
    
}